package org.gochev;

import javax.enterprise.inject.Model;
import javax.ws.rs.FormParam;

/**
 * Created by gochev on 9/30/15.
 */
@Model
//@Named("vlado")
//@RequestScoped
public class UserBean {

    @FormParam("firstName")
    private String firstName;

    @FormParam("lastName")
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
