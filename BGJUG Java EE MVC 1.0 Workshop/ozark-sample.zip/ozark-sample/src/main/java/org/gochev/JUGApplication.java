package org.gochev;

/**
 * Created by gochev on 9/30/15.
 */

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by bg-jug on 30.09.2015 */
@ApplicationPath("app")
public class JUGApplication extends Application {
}
