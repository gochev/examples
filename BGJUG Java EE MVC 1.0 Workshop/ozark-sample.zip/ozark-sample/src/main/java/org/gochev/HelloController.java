package org.gochev;

import javax.inject.Inject;
import javax.mvc.Controller;
import javax.mvc.Models;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Controller
@Path("hello")
public class HelloController {

    @Inject
    Models models;

    @Inject
    private UserBean userBean;

    @GET
    public String hello() {
        userBean.setFirstName("Bai Ivan neMaina");
        models.put("msg","Hello World!");
        return "/hello.jsp";
    }

//    @POST
//    public String postSomething(@BeanParam UserBean userBean) {
//
//    }
}
