package bg.jug.website.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author Ivan St. Ivanov
 */
@ApplicationPath("/app")
public class RestApplication extends Application {
}
